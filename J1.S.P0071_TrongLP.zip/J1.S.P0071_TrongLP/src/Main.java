
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Main {

    
    
    public static void main(String[] args) {
        View v = new View();
        v.display();
    }
    
}

